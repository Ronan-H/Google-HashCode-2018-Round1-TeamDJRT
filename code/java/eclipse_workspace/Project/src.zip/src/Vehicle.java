
public class Vehicle {
	public int row, col;
	public int destRow, destCol;
	public boolean occupied;
	boolean reachedRideStart;
	private Ride currentRide;
	
	public Vehicle()
	{
		this.row=0;
		this.col=0;
	}
	
	public void Vehicle(int row, int col)
	{
		this.row=row;
		this.col=col;
	}
	
	public void tick(int steps) {
		if (occupied) {
			if (row == destRow && col == destCol) {
				if (reachedRideStart) {
					occupied = false;
				}
				else {
					reachedRideStart = true;
					
					if (steps > currentRide.mustStart) {
						destRow = currentRide.destRow;
						destRow = currentRide.destCol;
					}
				}
				return;
			}
			else {
				// make way towards destination
				if (row != destRow) {
					if (row < destRow)
						++row;
					else
						--row;
				}
				else {
					// col != destCol
					if (col < destCol)
						++col;
					else
						--col;
				}
			}
		}
	}
	
	public void doRide(Ride ride) {
		destRow = ride.startRow;
		destCol = ride.startCol;
		occupied = true;
		reachedRideStart = false;
		currentRide = ride;
	}
	
}
